﻿namespace CrawfisSoftware.TicTacToeFramework
{
    public interface ITurnbasedScheduler
    {
        IPlayer SelectPlayer();
    }
}
