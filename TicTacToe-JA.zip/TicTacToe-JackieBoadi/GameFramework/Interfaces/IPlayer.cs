﻿namespace CrawfisSoftware.TicTacToeFramework
{
    public interface IPlayer
    {
        void TakeTurn();
    }
}