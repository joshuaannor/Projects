﻿using System;
using CrawfisSoftware.TicTacToeFramework;

namespace CrawfisSoftware.TicTacToeFramework
{
    public class PlayerDumb : IPlayer
    {
        private readonly CellState playerMark;
        private readonly IGameBoard<int, CellState> gameBoard;
        private readonly Random random;

        public PlayerDumb(CellState playerMark, IGameBoard<int, CellState> gameBoard)
        {
            this.playerMark = playerMark;
            this.gameBoard = gameBoard;
            this.random = new Random();
        }

        public void TakeTurn()
        {
            int cell = random.Next(0, 9);
            gameBoard.ChangeCellAttempt(cell, playerMark);
        }
    }
}