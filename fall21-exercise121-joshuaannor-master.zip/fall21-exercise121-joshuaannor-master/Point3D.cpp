#include "Point3D.h"
#include <iostream>
#include <string>
#include <cmath>


using std::cout;
using std::endl;
using std::string;
using std::to_string;

Point3D::Point3D(double xin, double yin, double zin)
{
	set(xin, yin, zin);
	
	
		

}
void Point3D::set(double xin, double yin, double zin)
{
	x = xin;
	y = yin;
	z = zin;
}

Point3D::Point3D()
{
	cout << " THe default Constructor is called " << endl;
 }

void Point3D::assign(const Point3D& point)
{
	set(point.x,point.y,point.z);
	
}
std::string Point3D::toString() const
{
	
	string C = to_string(x);
	string C1 = to_string(y);
	string C2 = to_string(z);
	string str1 = C + ',' + C1 + ',' + C2;

	return str1;
}
void Point3D::setX(double xin)
{
	x = xin;
}

void Point3D::setY(double yin)
{
	y = yin;
}

void Point3D::setZ(double zin)
{
	z = zin;
}
double Point3D::getX() const 
{
	return x;
}

double Point3D::getY() const
{
	return y;
}

double Point3D::getZ() const
{
	return z;
}

Point3D::~Point3D()
{
	// Nothing really to do since no resources were dynamically allocated,
	// so just write a message indicating that the destructor was called.
	std::cout << "Point3D destructor called" << std::endl;
}
void Point3D::scale(double factor)
{
	x *= factor;
	y *= factor;
	z *= factor;
}
void Point3D::translate(const Point3D& offset)
{
	x = x + offset.getX();
	y = y + offset.getY();
	z = z + offset.getZ();
}
void Point3D::rotate(Axis axis, double radians)
{
	double x_old{ x };
	double y_old{ y };
	double z_old{ z };

	double cosine{ cos(radians) };
	double sine{ sin(radians) };

	switch (axis) {
	case Axis::X_AXIS:
		y = (y_old * cosine) - (z_old * sine);
		z = (y_old * sine) + (z_old * cosine);
		break;
	case Axis::Y_AXIS:
		z = (z_old * cosine) - (x_old * sine);
		x = (z_old * sine) + (x_old * cosine);
		break;
	case Axis::Z_AXIS:
		x = (x_old * cosine) - (y_old * sine);
		y = (x_old * sine) + (y_old * cosine);
		break;
	default:
		break;
	}
}
