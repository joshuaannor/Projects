#include <string>

enum class Axis { X_AXIS, Y_AXIS, Z_AXIS };    // Used in the rotate() member function

// A class to represent and manipulate three-dimensional points.

class Point3D
{
public:
    Point3D(double x, double y, double z);   // Constructor with arguments
    Point3D();                               // Default constructor with no arguments

    ~Point3D();                              // Destructor

    void set(double x, double y, double z);  // Mutator member functions modify the object
    void setX(double x);
    void setY(double y);
    void setZ(double z);
    void assign(const Point3D& point);

    double getX() const;                     // Accessor member functions don't modify the object
    double getY() const;
    double getZ() const;
    std::string toString() const;

    void rotate(Axis axis, double radians);  // Point transformations
    void scale(double factor);
    void translate(const Point3D& offset);

private:
    double x{ 0.0 };                         // Data members should always be private
    double y{ 0.0 };
    double z{ 0.0 };
};
