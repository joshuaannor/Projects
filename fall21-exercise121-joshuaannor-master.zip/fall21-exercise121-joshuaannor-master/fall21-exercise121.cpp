#include "Point3D.h"
#include <iostream>


using std::cout;
using std::endl;


int main()
{
    
    Point3D point1( 5,5, 6 );
    cout << "point 1 is "<<point1.toString() << endl;
    Point3D point2;
    Point3D point3{ 5,2, 5 };
    cout << point1.toString() << endl;
    cout << point2.toString() << endl;
    cout << point3.toString() << endl;
    point1.setX(10.0);
    
    point1.setY(17.0);
   
    point1.setZ(11.0);
  

    cout << "point 1 is " << point1.toString() << endl;

    point1.scale(2.0);

    cout << "point 1 is " << point1.toString() << endl;
    point1.translate(point3);
    cout << "point 1 is " << point1.toString() << endl;
     

   
	return 0;
}
